Preview;
if noError == true
    
    if strcmpi(strtrim(sendData), "true")
        SendData;
    end
end
