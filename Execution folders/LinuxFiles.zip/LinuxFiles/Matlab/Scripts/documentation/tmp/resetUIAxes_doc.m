%% resetUIAxes(app)
%
% Reinicia el visor UIAxes de la interfície:
%
% * Neteja l'eix de coordenades
% * Restableix les etiquetes i els títols
% * Restableix els límits
% * Restableix la reixeta i la caixa
% * Restableix les escales a 'lineals'
%
% *PARÀMETRES D'ENTRADA*
%
% * |app: [App object]| -
% Inst&agrave;ncia de la classe de l'aplicació que creeu
%
% *VALORS DE SORTIDA*
%
% * No torna cap valor
%
