%% clearAllTable()
%% DESCRIPCIÓ
%
% Obté els noms de totes les taules existents al Workspace i les esborra
%
% *PARÀMETRES D'ENTRADA*
%
% * No es requereixen par&agrave;metres d'entrada
%
%
% *VALORS DE RETORN*
%
% No torna cap valor
%
