%% Título principal

%% Primera sección
% con algo de información importante

%% Segunda sección
% con algo de información importante