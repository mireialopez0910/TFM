addpath('tools');

xx = getWSTNByType('elda');

disp(xx.table_name);